"""
name: "Test GDAL"
requirements:
    - gdal
inputs:
outputs:
description: "Attempts to import gdal"
"""
# - scikit-learn

import gdal

def main():
    pass