"""
name: "Test GDAL"
requirements:
    - gdal
inputs:
outputs:
description: "Attempts to import gdal"
"""

from osgeo import gdal

def main():
    pass