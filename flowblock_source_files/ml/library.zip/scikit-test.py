"""
name: "Test ML"
requirements:
    - scikit-learn
inputs:
outputs:
    debug:
        type: Str
description: "Returns the sum of a and b"
"""
    # - ultralytics

# import pandas
from sklearn.datasets import load_iris
# import ultralytics

def main():
    return "Python ran"