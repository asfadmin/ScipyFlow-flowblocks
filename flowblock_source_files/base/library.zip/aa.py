"""
name: "a"
requirements:
inputs:
outputs:
    success:
        type: Bool
description: "dfsdfafasf"
"""

def main(path):
    return True
