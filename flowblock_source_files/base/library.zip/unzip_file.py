"""
name: "Unzip"
inputs:
    input_directory:
        type: Str
        user_input: Text
    output_directory:
        type: Str
        user_input: Text
outputs:
    output_directory:
        type: Str
description: "Unzips a zipped folder"
"""

import zipfile
import os

def main(input_directory, output_directory):
    with zipfile.ZipFile(input_directory, 'r') as zip_ref:
        zip_ref.extractall(output_directory)
        extracted_files = zip_ref.namelist()
    extracted_file_paths = [os.path.join(output_directory, file) for file in extracted_files]
    print(extracted_file_paths)
    return extracted_file_paths