"""
name: "Download From Web"
requirements:
    - requests
inputs:
    URL:
        type: Str
        default: "/"
        user_input: Text

    output_directory:
        type: Str
        user_input: Text
outputs:
    path:
        type: Str
description: "Downloads a file or folder from the web to the specified path"
"""
import os
import requests

def main(URL, output_directory):
    if URL.endswith("/"):
        download_directory(URL, output_directory)
    else:
        download_file()
        
    return output_directory

def download_directory(URL, output_directory):
    # Create output directory if not exist
    if not os.path.exists(output_directory):
        os.makedirs(output_directory)
    
    response = requests.get(URL)
    print(response)
    if response.status_code != 200:
        print(f"Failed to retrieve folder contents: {response.status_code}")
        return
    
    files = response.text
    print(files)

def download_file():
    pass

main("http://127.0.0.1:8000/test/", "/home/segallagher/Desktop/sklearn model training")