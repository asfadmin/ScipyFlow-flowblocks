"""
name: "<< Enter Flowblock Name >>"
requirements:
    - add
    - requirements
    - here
inputs:
    name_of_input_1:
        type: << Any, Bool, Binary, Set, Sequence, Str, Map, None, Number, UserInput, CustomClass(String) >>
        default: << Value this variable should default to >>
        user_input: << True, False >>
    name_of_input_N:
        type: << Any, Bool, Binary, Set, Sequence, Str, Map, None, Number, UserInput, CustomClass(String) >>
        default: << Value this variable should default to >>
        user_input: << True, False >>
outputs:
    name_of_output:
        type: << Any, Bool, Binary, Set, Sequence, Str, Map, None, Number, UserInput, CustomClass(String) >>
description: "<< Describe what this flowblock does >>"
"""

def main(name_of_input_1, name_of_input_N):
    # python code 
    return None
